#code, configure & run
main
controller
service
repository
entity

[run]
http://localhost:8080/user-portal/users
[
{
id: 1,
firstName: "fn",
lastName: "ln",
email: "e@e.com"
}
]